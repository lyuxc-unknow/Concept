![火盆](block:betterwithmods:hibachi)

火盆会在接受红石信号时向上点燃持续燃烧的火, 只有像火盆那样**持续**燃烧的火焰才能被[风箱](bellows.md).助燃而非吹灭